module.exports = {
    HOST: "localhost",
    USER: "admin",
    PASSWORD: "password",
    DB: "aula6"
}