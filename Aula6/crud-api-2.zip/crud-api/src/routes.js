const cursoController = require("./controllers/curso.controller");
const router = require("express").Router();

//CRUD
router.post('/create_course', cursoController.create);
router.get('/read_course', cursoController.read);
router.get('/read_all_courses', cursoController.listAll);
router.get('/read_course/:id', cursoController.read);
router.put("/update_course/:id", cursoController.update);
router.delete("/delete_course/:id", cursoController.delete);


module.exports = router;
